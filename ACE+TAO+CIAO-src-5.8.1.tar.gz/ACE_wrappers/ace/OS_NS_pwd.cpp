// $Id: OS_NS_pwd.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ace/OS_NS_pwd.h"

ACE_RCSID(ace, OS_NS_pwd, "$Id: OS_NS_pwd.cpp 80826 2008-03-04 14:51:23Z wotte $")

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_pwd.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

