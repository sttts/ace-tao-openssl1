// $Id: OS_NS_sys_resource.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ace/OS_NS_sys_resource.h"

ACE_RCSID(ace, OS_NS_sys_resource, "$Id: OS_NS_sys_resource.cpp 80826 2008-03-04 14:51:23Z wotte $")

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_sys_resource.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

