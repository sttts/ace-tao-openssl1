// $Id: Log_Msg_Backend.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ace/Log_Msg_Backend.h"

ACE_RCSID(ace, Log_Msg_Backend, "$Id: Log_Msg_Backend.cpp 80826 2008-03-04 14:51:23Z wotte $")


ACE_BEGIN_VERSIONED_NAMESPACE_DECL

ACE_Log_Msg_Backend::~ACE_Log_Msg_Backend (void)
{
}

ACE_END_VERSIONED_NAMESPACE_DECL
