// $Id: OS_NS_sys_time.cpp 80826 2008-03-04 14:51:23Z wotte $

#include "ace/OS_NS_sys_time.h"

ACE_RCSID(ace, OS_NS_sys_time, "$Id: OS_NS_sys_time.cpp 80826 2008-03-04 14:51:23Z wotte $")

#if !defined (ACE_HAS_INLINED_OSCALLS)
# include "ace/OS_NS_sys_time.inl"
#endif /* ACE_HAS_INLINED_OSCALLS */

